row = 1	
col = 1
open_spots = 0

parking_lot = [
    [0, 0, 0, 0, 0],
    [0, 1, 1, 2, 1],
    [0, 2, 2, 1, 1],
    [0, 0, 0, 0, 0],
    [0, 2, 1, 2, 1]
]

for row in parking_lot:
    for spot in row:
        if spot == 2:
            open_spots += 1

print(f"There are {open_spots} spots available")
